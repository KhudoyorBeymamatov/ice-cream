from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

# MySQL uchun aloqa o'rnatish
db = mysql.connector.connect(
    host="localhost",
    user="phpmyadmin",  # MySQL foydalanuvchi nomi
    password="root",  # MySQL paroli
    database="cream_factory"  # MySQL ma'lumotlar bazasi nomi
)
cursor = db.cursor()

@app.route('/')
def home():
    return render_template('index.html')


# Customer page uchun
@app.route('/customers')
def index():
    # Barcha mijozlarni olish
    cursor.execute("SELECT * FROM customers")
    customers = cursor.fetchall()
    return render_template('customers.html', customers=customers)

# Yangi mijoz qo'shish
@app.route('/add', methods=['POST'])
def add_customer():
    name = request.form['name']
    shopping_name = request.form['shopping_name']
    phone_number = request.form['phone_number']
    cursor.execute("INSERT INTO customers (name, shopping_name, phone_number) VALUES (%s, %s, %s)", (name, shopping_name, phone_number))
    db.commit()
    return redirect('/customers')

# Mijozni tahrirlash
@app.route('/update', methods=['POST'])
def update_customer():
    customer_id = request.form['customer_id']
    name = request.form['name']
    shopping_name = request.form['shopping_name']
    phone_number = request.form['phone_number']
    cursor.execute("UPDATE customers SET name=%s, shopping_name=%s, phone_number=%s WHERE id=%s", (name, shopping_name, phone_number, customer_id))
    db.commit()
    return redirect('/customers')

# Mijozni o'chirish
@app.route('/delete', methods=['POST'])
def delete_customer():
    customer_id = request.form['customer_id']
    cursor.execute("DELETE FROM customers WHERE id=%s", (customer_id,))
    db.commit()
    return redirect('/customers')


# employee page uchun
@app.route('/employees')
def index_em():
    # Barcha mijozlarni olish
    cursor.execute("SELECT * FROM employees")
    employees = cursor.fetchall()
    return render_template('employees.html', employees=employees)

# Yangi mijoz qo'shish
@app.route('/add_em', methods=['POST'])
def add_employee():
    name = request.form['name']
    address = request.form['address']
    salary = request.form['salary']
    cursor.execute("INSERT INTO employees (name, address, salary) VALUES (%s, %s, %s)", (name, address, salary))
    db.commit()
    return redirect('/employees')

# Mijozni tahrirlash
@app.route('/update_em', methods=['POST'])
def update_employee():
    employee_id = request.form['employee_id']
    name = request.form['name']
    address = request.form['address']
    salary = request.form['salary']
    cursor.execute("UPDATE employees SET name=%s, address=%s, salary=%s WHERE id=%s", (name, address, salary, employee_id))
    db.commit()
    return redirect('/employees')

# Mijozni o'chirish
@app.route('/delete_em', methods=['POST'])
def delete_employee():
    employee_id = request.form['employee_id']
    cursor.execute("DELETE FROM employees WHERE id=%s", (employee_id,))
    db.commit()
    return redirect('/employees')



# ice_cream_types page uchun
@app.route('/ice_cream_types')
def index_ice_cream_types():
    # Barcha mijozlarni olish
    cursor.execute("SELECT * FROM ice_cream_types")
    ice_cream_types = cursor.fetchall()
    return render_template('ice_cream_types.html', ice_cream_types=ice_cream_types)

# Yangi ice qo'shish
@app.route('/add_ice_cream_types', methods=['POST'])
def add_ice_cream_type():
    type = request.form['type']
    cursor.execute("INSERT INTO ice_cream_types (type) VALUES (%s)", [type])
    db.commit()
    return redirect('/ice_cream_types')

# Mijozni tahrirlash
@app.route('/update_ice_cream_type', methods=['POST'])
def update_ice_cream_type():
    ice_cream_type_id = request.form['ice_cream_type_id']
    type = request.form['type']
    cursor.execute("UPDATE ice_cream_types SET type=%s WHERE id=%s", (type, ice_cream_type_id))
    db.commit()
    return redirect('/ice_cream_types')

# Mijozni o'chirish
@app.route('/delete_ice_cream_type', methods=['POST'])
def delete_ice_cream_type():
    ice_cream_type_id = request.form['ice_cream_type_id']
    cursor.execute("DELETE FROM ice_cream_types WHERE id=%s", (ice_cream_type_id,))
    db.commit()
    return redirect('/ice_cream_types')


# ice_cream_types page uchun
@app.route('/ice_cream')
def index_ice_cream():
    # Barcha mijozlarni olish
    cursor.execute("  SELECT ice_cream.id, ice_cream.name, ice_cream.price, ice_cream_types.type FROM `ice_cream` INNER JOIN ice_cream_types on ice_cream.type_id = ice_cream_types.id")
    ice_cream = cursor.fetchall()

    cursor.execute("SELECT id, type FROM ice_cream_types")
    ice_cream_type_list = cursor.fetchall()

    return render_template('ice_cream.html', ice_cream=ice_cream, ice_cream_type_list = ice_cream_type_list)

# Yangi ice qo'shish
@app.route('/add_ice_cream', methods=['POST'])
def add_ice_cream():
    name = request.form['name']
    price = request.form['price']
    type_id = request.form['type_id']
    cursor.execute("INSERT INTO ice_cream (name, price, type_id) VALUES (%s,%s,%s)", (name, price, type_id))
    db.commit()
    return redirect('/ice_cream')

# Mijozni o'chirish
@app.route('/delete_ice_cream', methods=['POST'])
def delete_ice_cream():
    ice_id = request.form['ice_id']
    cursor.execute("DELETE FROM ice_cream WHERE id=%s", (ice_id,))
    db.commit()
    return redirect('/ice_cream')



# ice_cream_types page uchun
@app.route('/connect')
def index_conn():
    # Barcha mijozlarni olish
    cursor.execute("SELECT conn.id, customers.name, ice_cream.name, conn.quantity FROM `conn` INNER JOIN customers on customers.id = conn.customer_id INNER JOIN ice_cream on ice_cream.id = conn.ice_id")
    connect = cursor.fetchall()

    cursor.execute("SELECT id, name FROM customers")
    customer_lists = cursor.fetchall()

    cursor.execute("SELECT id, name FROM ice_cream")
    ice_cream_lists = cursor.fetchall()

    return render_template('connect.html', connect=connect, customer_lists = customer_lists, ice_cream_lists = ice_cream_lists)

# Yangi ice qo'shish
@app.route('/add_connect', methods=['POST'])
def add_conn():
    customer_id = request.form['customer_id']
    ice_id = request.form['ice_id']
    quantity = request.form['quantity']

    cursor.execute("INSERT INTO conn (customer_id, ice_id, quantity) VALUES (%s,%s,%s)", (customer_id, ice_id, quantity))
    db.commit()
    return redirect('/connect')

# Mijozni o'chirish
@app.route('/delete_connect', methods=['POST'])
def delete_conn():
    connect_id = request.form['connect_id']
    cursor.execute("DELETE FROM conn WHERE id=%s", (connect_id,))
    db.commit()
    return redirect('/connect')


# ice_cream_types page uchun
@app.route('/store_room')
def index_store_room():
    # Barcha mijozlarni olish
    cursor.execute("SELECT store_room.id, ice_cream.name, store_room.quantity, store_room.made_date, store_room.pull_date FROM `store_room` INNER JOIN ice_cream on ice_cream.id = store_room.ice_id")
    store_rooms = cursor.fetchall()

    cursor.execute("SELECT id, name FROM ice_cream")
    ice_cream_lists = cursor.fetchall()

    return render_template('store_room.html', store_rooms=store_rooms, ice_cream_lists = ice_cream_lists)

# Yangi ice qo'shish
@app.route('/add_store_room', methods=['POST'])
def add_store_room():
    ice_id = request.form['ice_id']
    quantity = request.form['quantity']
    made_date = request.form['made_date']
    pull_date = request.form['pull_date']

    cursor.execute("INSERT INTO store_room (ice_id, quantity, made_date, pull_date) VALUES (%s,%s,%s,%s)", (ice_id, quantity, made_date, pull_date))
    db.commit()
    return redirect('/store_room')

# Mijozni o'chirish
@app.route('/delete_store_room', methods=['POST'])
def delete_store_room():
    store_id = request.form['store_id']
    cursor.execute("DELETE FROM store_room WHERE id=%s", (store_id,))
    db.commit()
    return redirect('/store_room')


if __name__ == '__main__':
    app.run(debug=True)
