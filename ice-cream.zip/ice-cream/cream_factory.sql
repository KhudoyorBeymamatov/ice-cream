-- phpMyAdmin SQL Dump
-- version 5.2.1deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 15, 2023 at 07:23 AM
-- Server version: 10.11.2-MariaDB-1
-- PHP Version: 8.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cream_factory`
--

-- --------------------------------------------------------

--
-- Table structure for table `conn`
--

CREATE TABLE `conn` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `ice_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `conn`
--

INSERT INTO `conn` (`id`, `customer_id`, `ice_id`, `quantity`) VALUES
(2, 2, 1, 125),
(3, 7, 1, 120),
(4, 8, 1, 25);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `shopping_name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `shopping_name`, `phone_number`) VALUES
(7, 'Kopolboyev Doston', 'Murodshop123', '914523669'),
(8, 'Dostov Ogabek', 'ogobek shop', '915236545'),
(9, 'doston karimov', 'doston building 2', '912564589');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `address`, `salary`) VALUES
(1, 'Babajanov Boburbek', 'Urganch city', 100000),
(2, 'Kopolboyev Doston', 'Xazorasp ', 100000),
(4, 'Urinboyev Umid', 'Qoshkopir city', 100000),
(5, 'Gulya', 'Xonqa city', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `ice_cream`
--

CREATE TABLE `ice_cream` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ice_cream`
--

INSERT INTO `ice_cream` (`id`, `name`, `price`, `type_id`) VALUES
(1, 'xochu', 121, 2),
(2, 'vega', 145, 2),
(3, 'ming bir kecha', 250, 1),
(4, 'best', 2000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ice_cream_types`
--

CREATE TABLE `ice_cream_types` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ice_cream_types`
--

INSERT INTO `ice_cream_types` (`id`, `type`) VALUES
(1, 'shokoladli'),
(2, 'qaymoqli'),
(4, 'yongoqli');

-- --------------------------------------------------------

--
-- Table structure for table `store_room`
--

CREATE TABLE `store_room` (
  `id` int(11) NOT NULL,
  `ice_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `made_date` timestamp NULL DEFAULT current_timestamp(),
  `pull_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store_room`
--

INSERT INTO `store_room` (`id`, `ice_id`, `quantity`, `made_date`, `pull_date`) VALUES
(2, 2, 125, '2023-04-14 19:00:00', '2023-04-21'),
(3, 1, 12, '2023-04-18 19:00:00', '2023-04-07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `conn`
--
ALTER TABLE `conn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ice_cream`
--
ALTER TABLE `ice_cream`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ice_cream_types`
--
ALTER TABLE `ice_cream_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store_room`
--
ALTER TABLE `store_room`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `conn`
--
ALTER TABLE `conn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ice_cream`
--
ALTER TABLE `ice_cream`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ice_cream_types`
--
ALTER TABLE `ice_cream_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `store_room`
--
ALTER TABLE `store_room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
